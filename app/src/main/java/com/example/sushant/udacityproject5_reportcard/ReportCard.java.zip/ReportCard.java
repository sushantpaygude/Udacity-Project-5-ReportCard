package com.example.sushant.udacityproject5_reportcard;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ReportCard  {

    private String studentName;
    private String readingGrade;
    private String writingGrade;
    private String mathGrade;
    private String artGrade;
    private String finalGrade;

    public ReportCard(String studentName, String readingGrade, String writingGrade, String mathGrade, String artGrade, String finalGrade) {
        this.studentName = studentName;
        this.readingGrade = readingGrade;
        this.writingGrade = writingGrade;
        this.mathGrade = mathGrade;
        this.artGrade = artGrade;
        this.finalGrade = finalGrade;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getReadingGrade() {
        return readingGrade;
    }

    public String getWritingGrade() {
        return writingGrade;
    }

    public String getMathGrade() {
        return mathGrade;
    }

    public String getArtGrade() {
        return artGrade;
    }

    public String getFinalGrade() {
        return finalGrade;
    }

    @Override
    public String toString() {
        return "ReportCard{" +
                "finalGrade='" + finalGrade + '\'' +
                ", artGrade='" + artGrade + '\'' +
                ", mathGrade='" + mathGrade + '\'' +
                ", writingGrade='" + writingGrade + '\'' +
                ", readingGrade='" + readingGrade + '\'' +
                ", studentName='" + studentName + '\'' +
                '}';
    }
}
